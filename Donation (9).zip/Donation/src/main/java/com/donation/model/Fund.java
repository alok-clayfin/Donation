package com.donation.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@NoArgsConstructor
@ToString
public class Fund {
	
	@Id
	@GeneratedValue
	private Integer fundId;
	private String patientName;
	private Integer age;
	private String healthStatus;
	private String gender;
	private Long phoneNumber;
	private String cause;

	
	@OneToOne(cascade = { CascadeType.PERSIST,CascadeType.MERGE})
	private User user;
	@OneToOne(cascade = { CascadeType.PERSIST,CascadeType.MERGE})
	private Address address;
	@OneToOne(cascade = { CascadeType.PERSIST,CascadeType.MERGE})
	private Institution institution;
	@OneToOne(cascade = { CascadeType.PERSIST,CascadeType.MERGE})
	private Category category;
	
	
}
