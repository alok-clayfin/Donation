package com.donation.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor

public class Address {
	
	@Id
	@GeneratedValue
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "oracle6")
//	@SequenceGenerator(name = "oracle6", sequenceName = " ADDRESS_SEQUENCE", allocationSize = 1)
	private Integer addressId;
	private String street;
	@NotBlank(message="Field is mandatory")
	private String country;
	@NotBlank(message="Field is mandatory")
	private String state;

}
