package com.donation.model;

import java.sql.Time;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="donations")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class Donation {
	
	@Id
	@GeneratedValue
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "oracle4")
//	@SequenceGenerator(name = "oracle4", sequenceName = " DONATIONS_SEQUENCE", allocationSize = 1)
	private Integer id;
//	@NotNull(message="Enter Quantity")
	private Integer quantity;
//	@NotBlank(message="Enter User Name")
	private String userName;
//	@NotBlank(message="Enter Email Id")
	private String email;
//	@NotNull(message="Enter Amount")
	
	private Double amount;
//	@NotBlank(message="Enter Address")
	private String pickUpAddress;
//	@NotBlank(message="Enter Date and Time")
	private String pickUpDateTime;
//	@NotNull(message="Enter Phone Number")
//	@Pattern(regexp="^[+]91[6789]\\d{9}$", message="Enter mobile number and should be of 10digits ")
	private Long pickUpPhoneNumber;
	private String description;
	
	@OneToOne
	private Category category;
	@ManyToMany
	private List<Institution> institutionMap;
	
	@ManyToOne
	private User user;
	
	@ManyToMany
	private List<Address> address;
	

}
