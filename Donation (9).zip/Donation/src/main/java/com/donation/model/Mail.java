//package com.donation.model;
//
//import java.util.Map;
//
//import javax.mail.internet.InternetAddress;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.Id;
//
//import groovy.transform.ToString;
//import lombok.AllArgsConstructor;
//import lombok.Getter;
//import lombok.NoArgsConstructor;
//import lombok.Setter;
//
//@Entity
//@Getter
//@Setter
//@ToString
//@AllArgsConstructor
//@NoArgsConstructor
//public class Mail {
//	
//	@Id
//	@GeneratedValue
//	private String from;
//    private String to;
//    private String subject;
//    private String content;
//
//}
