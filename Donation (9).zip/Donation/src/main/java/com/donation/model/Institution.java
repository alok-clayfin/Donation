package com.donation.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor

public class Institution {
	@Id
	@GeneratedValue
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "oracle3")
//	@SequenceGenerator(name = "oracle3", sequenceName = " INSTITUTION_SEQUENCE", allocationSize = 1)
	private Integer instituteId;
	@NotBlank(message = "Institution Name is mandatory")
	private String institutionName;
	@NotBlank(message = "Institution Type is mandatory")
	private String institutionType;
	@NotBlank(message = "Institution  is mandatory")
	private String institutionHelpsTo;
	@NotNull(message = "Phone number is mandatory")
	@Pattern(regexp="^[6789]\\d{9}$", message="Institution mobile no should start with +91 and should be of 10digits ")
	private String institutionPhoneNumber;
	
}
