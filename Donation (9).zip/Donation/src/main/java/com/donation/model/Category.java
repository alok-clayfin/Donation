package com.donation.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@ToString

//@AllArgsConstructor
//@NoArgsConstructor
public class Category {
	@Id
	@GeneratedValue
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "oracle5")
//	@SequenceGenerator(name = "oracle5", sequenceName = " CATEGORY_SEQUENCE", allocationSize = 1)
	@Column(name = "id")
	private Integer categoryId;
	
	@NotBlank(message = "Category is mandatory")
	private String categoryName;
	
	public Category() {
		// TODO Auto-generated constructor stub
	}
	public Category(String categoryName) {
		super();
		System.out.println("obj created");
		//this.categoryId = categoryId;
		this.categoryName = categoryName;
	}
	
	
}
