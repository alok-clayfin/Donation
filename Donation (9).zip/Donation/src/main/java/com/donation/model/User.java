package com.donation.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.beust.jcommander.internal.Nullable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="Users")
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class User implements Serializable{
	@Id
	@GeneratedValue
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "oracle1")
//	@SequenceGenerator(name = "oracle1", sequenceName = " USERS_SEQUENCE", allocationSize = 1)
	private Integer id;
	private String userName;
	private String firstName;
	private String lastName;
	private Long phoneNumber;
	private String email;
	private String password;
	private String role;
	@Column(nullable = true)
	private Boolean enabled;
	

}
