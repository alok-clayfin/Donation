package com.donation.service;

import java.util.List;

import com.donation.model.Donation;

public interface IDonartionService {
	
	Donation addDonation(Donation donation);
	Donation updateDonation(Integer id);
	void deleteDonation(Integer id);
	List<Donation> viewDonationList();
	Donation viewDonationById(Integer id);


}
