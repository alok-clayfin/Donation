package com.donation.service;

import java.util.List;

import com.donation.model.Address;


public interface IAddressService {

	Address addAddress( Address address);
	Address updateAddress(Integer  addressId);
	void deleteAddress(Integer addressId); 
	List<Address> viewAddressList();

}
