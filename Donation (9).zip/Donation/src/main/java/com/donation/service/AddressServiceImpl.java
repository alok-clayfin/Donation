package com.donation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.donation.dao.AddressRepository;
import com.donation.exceptions.ResourceNotFoundException;
import com.donation.model.Address;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class AddressServiceImpl implements IAddressService{

	private AddressRepository addressRepository;
	@Autowired
	public AddressServiceImpl(AddressRepository addressRepository) {
		// TODO Auto-generated constructor stub
		this.addressRepository=addressRepository;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	addAddress(Address address)
	 - Input Parameters	:	address 
	 - Return Type		:	address
	 - Throws			:  	ResourceNotFoundException
	 - Author			:	ALOK SHREE
	 - Description		:	AddAddress
	 * @return 
	 ********************************************************************************************************/
	
	@Override
	public Address addAddress(Address address) {
		// TODO Auto-generated method stub
		Address ads=addressRepository.save(address);
		log.info("Address Added");
		return ads;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	updateAddress(Integer addressId)
	 - Input Parameters	:	id 
	 - Return Type		:	address
	 - Throws			:  	ResourceNotFoundException
	 - Author			:	ALOK SHREE
	 - Description		:	UpdateAddress
	 ********************************************************************************************************/

	@Override
	public Address updateAddress(Integer addressId) {
		// TODO Auto-generated method stub
		if(!addressRepository.existsById(addressId)) {
			log.error("No Address found with id = "+ addressId);
			throw new ResourceNotFoundException("No Address found with Id");
		}
		log.info("Address Updated");
		return addressRepository.findById(addressId).get();
	}
	
	/*******************************************************************************************************
	 - Function Name	:	deleteAddress(Integer addressId)
	 - Input Parameters	:	id 
	 - Return Type		:	address
	 - Throws			:  	ResourceNotFoundException
	 - Author			:	ALOK SHREE
	 - Description		:	DeleteAddress
	 ********************************************************************************************************/

	@Override
	public void deleteAddress(Integer addressId) {
		// TODO Auto-generated method stub
		if(!addressRepository.existsById(addressId)) {
			log.error("No address found with id = "+ addressId);
			throw new ResourceNotFoundException("No Address found with Id");
		}
		addressRepository.deleteById(addressId);
		log.info("Address Deleted");
		
	}
	
	/*******************************************************************************************************
	 - Function Name	:	viewAddressList()
	 - Input Parameters	:	
	 - Return Type		:	address
	 - Throws			:  	ResourceNotFoundException
	 - Author			:	ALOK SHREE
	 - Description		:	ViewAllAddress
	 ********************************************************************************************************/

	@Override
	public List<Address> viewAddressList() {
		// TODO Auto-generated method stub
		return addressRepository.findAll();
	}

}
