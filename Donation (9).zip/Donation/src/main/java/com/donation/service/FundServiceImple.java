package com.donation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.donation.dao.FundRepository;
import com.donation.model.Fund;

import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class FundServiceImple implements IFundService{

	private FundRepository fundRepository;
	@Autowired
	public FundServiceImple(FundRepository fundRepository) {
		// TODO Auto-generated constructor stub
		this.fundRepository=fundRepository;
	}
	
	@Override
	public Fund addFund(Fund fund) {
		// TODO Auto-generated method stub
		Fund fun=fundRepository.save(fund);
		log.info("Fund saved successfully");
		return fun;
	}

	@Override
	public List<Fund> viewFundList() {
		// TODO Auto-generated method stub
		return fundRepository.findAll();
	}

	@Override
	public Fund viewFundById(Integer fundId) {
		// TODO Auto-generated method stub
		Fund fun=fundRepository.findById(fundId).orElseThrow();
		log.info("fund fetching By ID");
		return fun;
	}

}
