package com.donation.service;

import java.util.List;

import com.donation.model.Category;



public interface ICategoryService {

	void addCategory( Category category);
	Category updateCategory(Integer  categoryId);
	void deleteCategory(Integer categoryId); 
	List<Category> viewCategoryList();

}
