package com.donation.service;

import java.util.List;

import com.donation.model.Fund;

public interface IFundService {
	Fund addFund(Fund fund);
	List<Fund> viewFundList();
	Fund viewFundById(Integer fundId);
}
