package com.donation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.donation.dao.DonationRepository;
import com.donation.exceptions.ResourceNotFoundException;
import com.donation.model.Donation;

import lombok.extern.java.Log;
import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class DonationService implements IDonartionService {

	@Autowired
	private EmailSenderService emailSenderService;
	
	@Autowired
	private DonationRepository donationRepository;

	/*******************************************************************************************************
	 - Function Name	:	addDonation(Donation donation)
	 - Input Parameters	:	donation 
	 - Return Type		:	donation
	 - Throws			:  	ResourceNotFoundException
	 - Author			:	ALOK SHREE
	 - Description		:	AddDonation
	 ********************************************************************************************************/
	
	@Override
	public Donation addDonation(Donation donation) {
		// TODO Auto-generated method stub
		Donation don= donationRepository.save(donation);
		log.info("Donation Saved");
		
		emailSenderService.sendSimpleMessage(donation.getEmail(), "Thank You for Donation", "Thank you for donating to DonationONE.");
		
		return don;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	updateDonation(Integer id)
	 - Input Parameters	:	id 
	 - Return Type		:	donation
	 - Throws			:  	ResourceNotFoundException
	 - Author			:	ALOK SHREE
	 - Description		:	UpdateDonation
	 ********************************************************************************************************/

	@Override
	public Donation updateDonation(Integer id) {
		// TODO Auto-generated method stub
		if (!donationRepository.existsById(id))
		 {
			  log.error("No Donation found with id = " + id);
		      throw new ResourceNotFoundException("No Donation found with id = " + id);
		 }
		log.info("Donation Updated");
		return donationRepository.findById(id).get();
	}
	
	/*******************************************************************************************************
	 - Function Name	:	deleteDonation(Integer id)
	 - Input Parameters	:	id 
	 - Return Type		:	void
	 - Throws			:  	ResourceNotFoundException
	 - Author			:	ALOK SHREE
	 - Description		:	DeleteDonation
	 ********************************************************************************************************/

	@Override
	public void deleteDonation(Integer id) {
		// TODO Auto-generated method stub
		if (!donationRepository.existsById(id))
		 {
			  log.error("No Donation found with id = " + id);
		      throw new ResourceNotFoundException("No Donation found with id = " + id);
		 }
		donationRepository.deleteById(id);
		log.info("Donation Deleted");
	}

	/*******************************************************************************************************
	 - Function Name	:	viewDonationList()
	 - Return Type		:	List<Donation>
	 - Throws			:  	ResourceNotFoundException
	 - Author			:	ALOK SHREE
	 - Description		:	ViewAllDonationList
	 ********************************************************************************************************/
	
	@Override
	public List<Donation> viewDonationList() {
		// TODO Auto-generated method stub
		return donationRepository.findAll();
	}
	
	/*******************************************************************************************************
	 - Function Name	:	viewDonationById(Integer id)
	 - Input Parameters	:	id 
	 - Return Type		:	donation
	 - Throws			:  	ResourceNotFoundException
	 - Author			:	ALOK SHREE
	 - Description		:	ViewDonationBy Id
	 ********************************************************************************************************/

	@Override
	public Donation viewDonationById(Integer id) {
		// TODO Auto-generated method stub
		Donation donation=donationRepository.findById(id).orElseThrow();
		log.info("Donation fetching By ID");
		return donation;
	}
	
	
	
}
