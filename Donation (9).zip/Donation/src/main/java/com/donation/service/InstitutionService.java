package com.donation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.donation.dao.InstitutionRepository;
import com.donation.exceptions.ResourceNotFoundException;
import com.donation.model.Institution;
import com.donation.model.User;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class InstitutionService implements IInstitutionService{

	private InstitutionRepository institutionRepository;
	@Autowired
	public InstitutionService(InstitutionRepository institutionRepository) {
		// TODO Auto-generated constructor stub
		this.institutionRepository=institutionRepository;
	}
	@Override
	public void addInstitution(Institution institution) {
		// TODO Auto-generated method stub
		institutionRepository.save(institution);
		log.info("Institution saved");
		
	}

	@Override
	public Institution updateInstitution(Integer id) {
		// TODO Auto-generated method stub
		if (!institutionRepository.existsById(id))
		 {
			  log.error("No Institution found with id = " + id);
		      throw new ResourceNotFoundException("No Institution found with id = " + id);
		 }
		log.info("Institution updated");
		return institutionRepository.findById(id).get();
	}

	@Override
	public void deleteInstitution(Integer id) {
		// TODO Auto-generated method stub
		if (!institutionRepository.existsById(id))
		{
			  log.error("No Institution found with id = " + id);
		      throw new ResourceNotFoundException("No Institution found with id = " + id);
		 }
		institutionRepository.deleteById(id);
		log.info("Institution Deleted");
	}

	@Override
	public List<Institution> viewInstitutionList() {
		// TODO Auto-generated method stub
		System.out.println(institutionRepository.findAll());
		return institutionRepository.findAll();
	}

}
