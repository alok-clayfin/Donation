package com.donation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.donation.dao.AdminRepository;
import com.donation.exceptions.ResourceNotFoundException;
import com.donation.model.User;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class AdminService implements IAdminService{

	
	private AdminRepository adminRepository;
	@Autowired
	public AdminService(AdminRepository adminRepository) {
		// TODO Auto-generated constructor stub
		this.adminRepository=adminRepository;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	addUser(User user)
	 - Input Parameters	:	user 
	 - Return Type		:	void
	 - Throws			:  	ResourceNotFoundException
	 - Author			:	ALOK SHREE
	 - Description		:	AddUser
	 ********************************************************************************************************/
	
	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		
		User user1=adminRepository.save(user);
		log.info("User Added");
		return user1;
		
	}
	
	/*******************************************************************************************************
	 - Function Name	:	viewUserList()
	 - Input Parameters	:	
	 - Return Type		:	List<User>
	 - Throws			:  	ResourceNotFoundException
	 - Author			:	ALOK SHREE
	 - Description		:	ViewAllUserList
	 ********************************************************************************************************/
	
	@Override
	public List<User> viewUserList() {
		// TODO Auto-generated method stub
		System.out.println(adminRepository.findAll());
		return adminRepository.findAll();
	}

	/*******************************************************************************************************
	 - Function Name	:	updateUser(Integer Id)
	 - Input Parameters	:	id 
	 - Return Type		:	user
	 - Throws			:  	ResourceNotFoundException
	 - Author			:	ALOK SHREE
	 - Description		:	UpdateUser
	 ********************************************************************************************************/
	
	@Override
	public User updateUser(Integer id) {
		// TODO Auto-generated method stub
		System.out.println(adminRepository.findById(id).get());
		
		if (!adminRepository.existsById(id))
		 {
			  log.error("No User found with id = " + id);
		      throw new ResourceNotFoundException("No User found with id = " + id);
		 }
		log.info("User Updated");
		return adminRepository.findById(id).get();
		
	}
	
	/*******************************************************************************************************
	 - Function Name	:	deleteUser(Integer Id)
	 - Input Parameters	:	id 
	 - Return Type		:	user
	 - Throws			:  	ResourceNotFoundException
	 - Author			:	ALOK SHREE
	 - Description		:	deleteUser
	 ********************************************************************************************************/

	@Override
	public void deleteUser(Integer id) {
		// TODO Auto-generated method stub
		if (!adminRepository.existsById(id))
		 {
			  log.error("No User found with id = " + id);
		      throw new ResourceNotFoundException("No User found with id = " + id);
		 }
		adminRepository.deleteById(id);
		log.info("User Deleted");
	}
	
	/*******************************************************************************************************
	 - Function Name	:	existsUserByEmailAndPassword(String email, String password)
	 - Input Parameters	:	String email, String password 
	 - Return Type		:	boolean
	 - Throws			:  	ResourceNotFoundException
	 - Author			:	ALOK SHREE
	 - Description		:	Exists User By Email and Password
	 ********************************************************************************************************/

	@Override
	public Boolean existsUserByEmailAndPassword(String email, String password) {
		if(!adminRepository.existsUserByEmailAndPassword(email, password)) {
			log.error("no email and password is exists");
		}
		log.info("user successfully sent");
		return adminRepository.existsUserByEmailAndPassword(email, password);
	}
	
	/*******************************************************************************************************
	 - Function Name	:	findRole(String email)
	 - Input Parameters	:	email 
	 - Return Type		:	user
	 - Throws			:  	ResourceNotFoundException
	 - Author			:	ALOK SHREE
	 - Description		:	Find Role
	 ********************************************************************************************************/

	@Override
	public User findRole(String email) {
		log.info("user seccessfully dedected");
		return adminRepository.findByEmail(email);
	}

	

	
	

}
