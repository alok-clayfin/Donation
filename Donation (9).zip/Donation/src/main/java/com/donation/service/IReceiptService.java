//package com.donation.service;
//
//import java.util.List;
//
//import com.donation.model.Donation;
//
//
//public interface IReceiptService {
//	
//	List<Donation> viewUserList();
//}
