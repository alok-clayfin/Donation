package com.donation.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.donation.dao.CategoryRepository;
import com.donation.exceptions.ResourceNotFoundException;
import com.donation.model.Category;

import lombok.extern.log4j.Log4j2;

@Log4j2
@Service
public class CategoryService implements ICategoryService{

	private CategoryRepository categoryRepository;
	
	@Autowired
	public CategoryService(CategoryRepository categoryRepository) {
		// TODO Auto-generated constructor stub
		this.categoryRepository=categoryRepository;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	addCategory(Category category)
	 - Input Parameters	:	category 
	 - Return Type		:	void
	 - Throws			:  	ResourceNotFoundException
	 - Author			:	ALOK SHREE
	 - Description		:	AddCategory
	 ********************************************************************************************************/
	
	@Override
	public void addCategory(Category category) {
		// TODO Auto-generated method stub
		categoryRepository.save(category);
		log.info("Category Added");
	}
	
	/*******************************************************************************************************
	 - Function Name	:	updateCategory(Integer categoryId)
	 - Input Parameters	:	categoryId 
	 - Return Type		:	Category
	 - Throws			:  	ResourceNotFoundException
	 - Author			:	ALOK SHREE
	 - Description		:	UpdateCategory
	 ********************************************************************************************************/

	@Override
	public Category updateCategory(Integer categoryId) {
		// TODO Auto-generated method stub
		if (!categoryRepository.existsById(categoryId))
		 {
			  log.error("No Category found with id = " + categoryId);
		      throw new ResourceNotFoundException("No Category found with id = " + categoryId);
		 }
		log.info("Category Updated");
		return categoryRepository.findById(categoryId).get();
	}
	
	/*******************************************************************************************************
	 - Function Name	:	deleteCategory(Integer categoryId)
	 - Input Parameters	:	categoryId 
	 - Return Type		:	void
	 - Throws			:  	ResourceNotFoundException
	 - Author			:	ALOK SHREE
	 - Description		:	DeleteCategory
	 ********************************************************************************************************/

	@Override
	public void deleteCategory(Integer categoryId) {
		// TODO Auto-generated method stub
		if (!categoryRepository.existsById(categoryId))
		 {
			  log.error("No category found with id = " + categoryId);
		      throw new ResourceNotFoundException("No category found with id = " + categoryId);
		 }
		categoryRepository.deleteById(categoryId);
		log.info("Category Deleted");
	}
	
	/*******************************************************************************************************
	 - Function Name	:	viewCategoryList()
	 - Return Type		:	List<Category>
	 - Throws			:  	ResourceNotFoundException
	 - Author			:	ALOK SHREE
	 - Description		:	ViewAllCategory
	 ********************************************************************************************************/

	@Override
	public List<Category> viewCategoryList() {
		// TODO Auto-generated method stub
		return categoryRepository.findAll();
	}

}
