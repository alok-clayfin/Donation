//package com.donation.service;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.donation.dao.DonationRepository;
//import com.donation.model.Donation;
//
//@Service
//public class ReceiptService implements IReceiptService{
//	
//	@Autowired
//	private DonationRepository donationRepo;
//	
//	@Override
//	public List<Donation> viewUserList() {
//		// TODO Auto-generated method stub
//		return donationRepo.findAll();
//	}
//	
//	
//
//}
