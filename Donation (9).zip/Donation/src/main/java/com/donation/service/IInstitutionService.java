package com.donation.service;

import java.util.List;

import com.donation.model.Institution;
import com.donation.model.User;

public interface IInstitutionService {

	void addInstitution( Institution institution);
	Institution updateInstitution(Integer  id);
	void deleteInstitution(Integer id); 
	List<Institution> viewInstitutionList();
}
