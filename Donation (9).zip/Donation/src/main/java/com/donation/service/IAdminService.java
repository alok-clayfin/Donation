package com.donation.service;

import java.util.List;

import org.springframework.stereotype.Service;
import com.donation.model.User;


public interface IAdminService {
	
	User addUser( User user);
	User updateUser(Integer  id);
	void deleteUser(Integer id); 
	List<User> viewUserList();
	Boolean existsUserByEmailAndPassword(String email, String password) ;
	User findRole(String email);
	
}
