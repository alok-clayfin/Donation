package com.donation.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.donation.dao.AdminRepository;
import com.donation.model.User;
import com.donation.service.AdminService;

import lombok.extern.log4j.Log4j2;



@Controller
@Log4j2
//@RequestMapping("/admin")
public class AdminUserController {
	
//	@Autowired
//	private BCryptPasswordEncoder passwordEncoder;
	@Autowired
	private AdminRepository adminRepository;
	
	private AdminService adminService;
	@Autowired
	public AdminUserController(AdminService adminService) {
		// TODO Auto-generated constructor stub
		this.adminService=adminService;
	}
	
	@GetMapping("/admin")
	public String adminPanel() {
		return "adminHomePage";
	}
	
	
	@GetMapping("/addUser")
	public ModelAndView addUser(HttpSession session)
	{
//		String userRole=(String)session.getAttribute("userRole");
//		System.out.println(userRole);
//		User user=adminService.findRole(userRole);
		
		User user=new User();
		ModelAndView mv= new ModelAndView("register");
		mv.addObject("user", user);
		return mv;
	}
	
	@PostMapping("/registerUser")
	public String saveUser(@ModelAttribute User user,HttpSession session) {
		// List<User> users= userService.viewUserList();
		String userRole=(String)session.getAttribute("userRole");
		System.out.println(userRole);
		//User role=adminService.findRole("admin");
		adminService.addUser(user);
		if(userRole.equals("admin")) {
			log.info("going to user list page");
			return "redirect:/listUser";
		}
		else if(userRole.equals(null)) {
			log.info("going to index page");
			return "index";
		}
		else {
			return "index";
		}
	}

	
	
	@GetMapping({"/user","/listUser"})
	public ModelAndView getAllUser() {
		ModelAndView mav = new ModelAndView("listUser");
		List<User> users= adminService.viewUserList();
		mav.addObject("users", users);
		
		return mav;
	}
	
	
	@GetMapping("/showUpdateForm")
	public ModelAndView showUpdateForm(@RequestParam Integer id) {
		ModelAndView mav = new ModelAndView("register");
		mav.addObject("user", adminService.updateUser(id));
		return mav;
	}
	
	@GetMapping("/deleteUser")
	public String deleteUser(@RequestParam Integer id) {
		adminService.deleteUser(id);
		return "redirect:/listUser";
	}
	
}
