package com.donation.controller;

import java.util.Optional;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.donation.dao.AdminRepository;
import com.donation.model.User;
import com.donation.service.AdminService;

import lombok.extern.log4j.Log4j2;

@Controller
@Log4j2
public class ProfileController {
	
	@Autowired
	private AdminService adminService;
	private AdminRepository adminRepository;
	
	@Autowired
	public ProfileController(AdminRepository adminRepository) {
		// TODO Auto-generated constructor stub
		this.adminRepository=adminRepository;
	}
	
	@GetMapping("/profile")
	public ModelAndView profilePage(HttpSession session) {
		//User user=(User)session.getAttribute("user");
		Integer userId=(Integer)session.getAttribute("userId");
		System.out.println(userId);
		ModelAndView mav=new ModelAndView("userProfile");
		User user=adminRepository.findById(userId).orElseThrow();
		
		mav.addObject("user", user);
		log.info("getting inside user profile with active session");
		return mav;
	}
	
}
