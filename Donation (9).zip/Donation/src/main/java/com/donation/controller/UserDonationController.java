package com.donation.controller;

import java.security.Principal;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.donation.dao.AdminRepository;
import com.donation.model.Address;
import com.donation.model.Category;
import com.donation.model.Donation;
import com.donation.model.Institution;
import com.donation.model.User;
import com.donation.service.AddressServiceImpl;
import com.donation.service.CategoryService;
import com.donation.service.DonationService;
import com.donation.service.InstitutionService;
import com.fasterxml.jackson.annotation.JsonCreator.Mode;

@Controller
@RequestMapping("/user")
public class UserDonationController {
	@Autowired
	private CategoryService categoryService;
//	@Autowired
//	private BCryptPasswordEncoder passwordEncoder;
	@Autowired
	private InstitutionService institutionService;
	private DonationService donationService;
	@Autowired
	private AddressServiceImpl addressServiceImpl;
	@Autowired
	private AdminRepository adminRepository;
	
	@Autowired
	public UserDonationController(DonationService donationService) {
		// TODO Auto-generated constructor stub
		this.donationService = donationService;
	}

	@GetMapping("/donation")
	public String donation(HttpSession session) {
		User user=(User)session.getAttribute("user");
		return "userHomePage";
	}

	
	@GetMapping("/addMoney") 
	public ModelAndView addMoney() {
		
		Donation donation=new Donation();
		List<Address> address = addressServiceImpl.viewAddressList();
		List<Category> category= categoryService.viewCategoryList();
		List<Institution> institution=institutionService.viewInstitutionList();
		ModelAndView mav=new ModelAndView("moneyDonation");
		mav.addObject("donation", donation);
		mav.addObject("category", category);
		mav.addObject("institution", institution);
		mav.addObject("address", address);
		return mav;
	}
	
//	@PostMapping("/moneyDonate")
//	public String addCategoryValid(@Valid @ModelAttribute Donation donation, BindingResult result) {
//	  if (result.hasErrors()) {
//	    return "moneyDonation";
//	  }
//	  Donation d= donationService.addDonation(donation);
//		int id=d.getId();
//		System.out.println(id);
//	  return "redirect:/receiptPage?id="+id;
//	}

	@PostMapping("/moneyDonate")
	public String moneyDonateReceipt(@ModelAttribute("donation") Donation donation)
	{
		Donation d= donationService.addDonation(donation);
		int id=d.getId();
		System.out.println(id);
		return "redirect:/user/receiptPage?id="+id;
	}
	
	@GetMapping("/receiptPage")
	public ModelAndView viewReceipt(@RequestParam Integer id) {
		ModelAndView mav=new ModelAndView("receiptMoney");
		Donation donation= donationService.viewDonationById(id);
		mav.addObject("donation", donation);
		return mav;
	}
	
	/* Here Food donation section is being created */

	@GetMapping("/addFood")
	public ModelAndView addFood() {
		Donation donation = new Donation();
		List<Address> address = addressServiceImpl.viewAddressList();
		List<Category> category= categoryService.viewCategoryList();
		List<Institution> institution=institutionService.viewInstitutionList();
		ModelAndView mav = new ModelAndView("foodDonation");
		mav.addObject("donation", donation);
		mav.addObject("category", category);
		mav.addObject("institution", institution);
		mav.addObject("address", address);
		return mav;
	}

	@PostMapping("/foodDonate")
	public String foodDonate(@ModelAttribute("donation") Donation donation) {
		
		Donation d= donationService.addDonation(donation);
		int id=d.getId();
		System.out.println(id);
		return "redirect:/user/receiptFoodPage?id="+id;
	}
	
	@GetMapping("/receiptFoodPage")
	public ModelAndView viewFoodReceipt(@RequestParam Integer id) {
		ModelAndView mav=new ModelAndView("receiptFood");
		Donation donation= donationService.viewDonationById(id);
		mav.addObject("donation", donation);
		return mav;
	}

	/* here other donation section is being donated */
	
	@GetMapping("/addOther")
	public ModelAndView addOther() {
		Donation donation = new Donation();
		List<Address> address = addressServiceImpl.viewAddressList();
		List<Category> category= categoryService.viewCategoryList();
		List<Institution> institution=institutionService.viewInstitutionList();
		ModelAndView mav = new ModelAndView("otherDonation");
		mav.addObject("donation", donation);
		mav.addObject("category", category);
		mav.addObject("institution", institution);
		mav.addObject("address", address);
		return mav;
	}

	@PostMapping("/otherDonate")
	public String otherDonate(@ModelAttribute("donation") Donation donation) {
		Donation d=donationService.addDonation(donation);
		int id=d.getId();
		System.out.println(id);
		return "redirect:/user/receiptOtherPage?id="+id;
	}
	
	@GetMapping("/receiptOtherPage")
	public ModelAndView viewOtherReceipt(@RequestParam Integer id) {
		ModelAndView mav=new ModelAndView("receiptOther");
		Donation donation= donationService.viewDonationById(id);
		mav.addObject("donation", donation);
		return mav;
	}
	
	//User profile Section start here
	

	

}
