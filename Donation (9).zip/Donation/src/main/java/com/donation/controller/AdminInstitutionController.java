package com.donation.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.donation.model.Category;
import com.donation.model.Institution;
import com.donation.service.InstitutionService;

@Controller
public class AdminInstitutionController {

	private InstitutionService institutionService;
	@Autowired
	public AdminInstitutionController(InstitutionService institutionService) {
		// TODO Auto-generated constructor stub
		this.institutionService=institutionService;
	}
	
	@GetMapping("/addInstitution")
	public ModelAndView addInstitution()
	{
		Institution institution=new Institution();
		ModelAndView mv= new ModelAndView("institutionForm");
		mv.addObject("institution", institution);
		//mv.setViewName("doctorRegistraction.html");
		return mv;
	}
	
	/*******************************************************************************************************
	- Function Name		: addInstitution()
	- Input Parameters	: Object
	- Return Type		: Redirect Page
	- Throws    		: ResourceNotFoundException
	- Author     		: ALOKSHREE 
	- Description		: calls service method InstitutionService;
	********************************************************************************************************/
	
	@PostMapping("/registerInstitution")
	public String addInstitutionValid(@Valid @ModelAttribute Institution institution, BindingResult result) {
	  if (result.hasErrors()) {
	    return "institutionForm";
	  }
	  institutionService.addInstitution(institution);
	  return "redirect:/institutionList";
	}	
	
//	@PostMapping("/registerInstitution")
//	public String saveInstitute(@ModelAttribute Institution institution) {
//		// List<User> users= userService.viewUserList();
//		institutionService.addInstitution(institution);
//		
//		return "redirect:/institutionList";
//	}

	
	@GetMapping({"/institution","/institutionList"})
	public ModelAndView getAllInstitution() {
		ModelAndView mav = new ModelAndView("institutionList");
		List<Institution> institutions= institutionService.viewInstitutionList();
		mav.addObject("institutions", institutions);
		
		return mav;
	}
	
	/*******************************************************************************************************
	- Function Name		: updateInstitutiony()
	- Input Parameters	: @RequestParam Integer
	- Return Type		: ModelAndView Object
	- Throws    		: ResourceNotFoundException
	- Author     		: ALOKSHREE 
	- Description		: calls service method InstitutionService;
	********************************************************************************************************/
	
	@GetMapping("/showUpdateInstitutionForm")
	public ModelAndView showUpdateForm(@RequestParam Integer instituteId) {
		ModelAndView mav = new ModelAndView("institutionForm");
		mav.addObject("institution", institutionService.updateInstitution(instituteId));
		return mav;
	}
	
	/*******************************************************************************************************
	- Function Name		: deleteInstitution()
	- Input Parameters	: @RequestParam Integer
	- Return Type		: Redirect Page
	- Throws    		: ResourceNotFoundException
	- Author     		: ALOKSHREE 
	- Description		: calls service method InstitutionService;
	********************************************************************************************************/
	
	@GetMapping("/deleteInstitution")
	public String deleteInstitution(@RequestParam Integer instituteId) {
		institutionService.deleteInstitution(instituteId);
		return "redirect:/institutionList";
	}

}
