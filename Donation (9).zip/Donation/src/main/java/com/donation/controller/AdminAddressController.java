package com.donation.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.donation.model.Address;
import com.donation.service.AddressServiceImpl;

@Controller
public class AdminAddressController {
	
	private AddressServiceImpl addressServiceImpl;
	@Autowired
	public AdminAddressController(AddressServiceImpl addressServiceImpl) {
		// TODO Auto-generated constructor stub
		this.addressServiceImpl=addressServiceImpl;
	}
	
	@GetMapping("/addAddress")
	public ModelAndView addAddress() {
		Address address = new Address();
		ModelAndView mav = new ModelAndView("addressForm");
		mav.addObject("address", address);
		return mav;
	}
	
	/*******************************************************************************************************
	- Function Name		: RegisterAddress()
	- Input Parameters	: Object
	- Return Type		: Redirect Page
	- Throws    		: ResourceNotFoundException
	- Author     		: ALOKSHREE 
	- Description		: calls service method AddressServiceImpl;
	********************************************************************************************************/
	
	@PostMapping("/registerAddress")
	public String addAddressValid(@Valid @ModelAttribute Address address, BindingResult result) {
		if(result.hasErrors()) {
			return "addressForm";
		}
		addressServiceImpl.addAddress(address);
		return "redirect:/addressList";
	}
	
	@GetMapping("/addressList")
	public ModelAndView getAllAddress() {
		ModelAndView mav = new ModelAndView("addressList");
		List<Address> addresss = addressServiceImpl.viewAddressList();
		mav.addObject("addresss", addresss);
		return mav;
	}
	
	/*******************************************************************************************************
	- Function Name		: UpdateAddressForm()
	- Input Parameters	: @RequestParam Integer
	- Return Type		: Object
	- Throws    		: ResourceNotFoundException
	- Author     		: ALOKSHREE 
	- Description		: calls service method AddressServiceImpl;
	********************************************************************************************************/
	
	@GetMapping("/showUpdateAddressForm")
	public ModelAndView showUpdateForm(@RequestParam Integer addressId) {
		ModelAndView mav= new ModelAndView("addressForm");
		mav.addObject("address", addressServiceImpl.updateAddress(addressId));
		return mav;
	}
	
	/*******************************************************************************************************
	- Function Name		: DeleteAddress()
	- Input Parameters	: @RequestParam Integer
	- Return Type		: Redirect Page
	- Throws    		: ResourceNotFoundException
	- Author     		: ALOKSHREE 
	- Description		: calls service method AddressServiceImpl;
	********************************************************************************************************/
	
	@GetMapping("/deleteAddress")
	public String deleteAddress(@RequestParam Integer addressId) {
		addressServiceImpl.deleteAddress(addressId);
		return "redirect:/addressList";
	}
}
