package com.donation.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.donation.model.Category;
import com.donation.service.CategoryService;

@Controller
public class AdminCategoryController {
	
	private CategoryService categoryService;
	
	@Autowired
	public AdminCategoryController(CategoryService categoryService) {
		// TODO Auto-generated constructor stub
		this.categoryService=categoryService;
	}
	
	@GetMapping("/addCategory")
	public ModelAndView addCategory()
	{
		Category category=new Category();
		ModelAndView mv= new ModelAndView("categoryForm");
		mv.addObject("category", category);
		//mv.setViewName("doctorRegistraction.html");
		return mv;
	}
	
	/*******************************************************************************************************
	- Function Name		: addCategory()
	- Input Parameters	: object
	- Return Type		: Redirect Page
	- Throws    		: ResourceNotFoundException
	- Author     		: ALOKSHREE 
	- Description		: calls service method CategoryService;
	********************************************************************************************************/
	
	@PostMapping("/registerCategory")
	public String addCategoryValid(@Valid @ModelAttribute Category category, BindingResult result) {
	  if (result.hasErrors()) {
	    return "categoryForm";
	  }
	  categoryService.addCategory(category);
	  return "redirect:/categoryList";
	}
	

	
	@GetMapping({"/categoryList"})
	public ModelAndView getAllCategory() {
		ModelAndView mav = new ModelAndView("categoryList");
		List<Category> categorys= categoryService.viewCategoryList();
		mav.addObject("categorys", categorys);
		
		return mav;
	}
	
	/*******************************************************************************************************
	- Function Name		: updateCategory()
	- Input Parameters	: @RequestParam Integer
	- Return Type		: ModelAndView
	- Throws    		: ResourceNotFoundException
	- Author     		: ALOKSHREE 
	- Description		: calls service method CategoryService;
	********************************************************************************************************/
	
	@GetMapping("/showUpdateCategoryForm")
	public ModelAndView showUpdateForm(@RequestParam Integer categoryId) {
		ModelAndView mav = new ModelAndView("categoryForm");
		mav.addObject("category", categoryService.updateCategory(categoryId));
		return mav;
	}
	
	/*******************************************************************************************************
	- Function Name		: deleteCategory()
	- Input Parameters	: @RequestParam Integer
	- Return Type		: Redirect Page
	- Throws    		: ResourceNotFoundException
	- Author     		: ALOKSHREE 
	- Description		: calls service method CategoryService;
	********************************************************************************************************/
	
	@GetMapping("/deleteCategory")
	public String deleteCategory(@RequestParam Integer categoryId) {
		categoryService.deleteCategory(categoryId);
		return "redirect:/categoryList";
	}

}
