package com.donation.controller;

import javax.mail.Session;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.donation.model.Address;
import com.donation.model.Fund;
import com.donation.model.User;
import com.donation.service.AddressServiceImpl;
import com.donation.service.AdminService;
import com.donation.service.CategoryService;
import com.donation.service.FundServiceImple;
import com.donation.service.InstitutionService;

import lombok.Getter;
import lombok.extern.log4j.Log4j2;

@Controller
@Log4j2

public class FundController {
	
	@Autowired
	private FundServiceImple fundServiceImple;
	@Autowired
	private AdminService adminService;
	@Autowired
	private CategoryService categoryService;
	@Autowired
	private AddressServiceImpl addressServiceImpl;
	@Autowired
	private InstitutionService institutionService;
	
	
	@GetMapping("/userForm")
	public ModelAndView userDetail() {
		User user=new User();
		ModelAndView mav=new ModelAndView("fundForm1");
		mav.addObject("user", user);
		log.info("getting in userDetail");
		return mav;
	}

	@PostMapping("/userDetail")
	public String addUserDetail(@Valid @ModelAttribute User user, BindingResult result) {
		
		User us=adminService.addUser(user);
		
		//session.setAttribute("user", us);
		log.info("getting in adduserDetail");
		
		return "redirect:/fundForm";	
	}
	
	@GetMapping("/fundForm")
	public ModelAndView fundDetail() {
		//User usr=(User)session.getAttribute("user");
		ModelAndView mav=new ModelAndView("fundForm2");
		Fund fund=new Fund();
		mav.addObject("fund", fund);
		log.info("getting in fundDetail");
		return mav;
	}
	
	@PostMapping("/fundDetail")
	public String addFundDetail(@Valid @ModelAttribute Fund fund, BindingResult result) {
		Fund fd=fundServiceImple.addFund(fund);
		//session.setAttribute("fund", fundServiceImple.addFund(fund) );
		log.info("getting in addFundDetail");
		return "redirect:/addressForm";
	}
	
	@GetMapping("/addressForm")
	public ModelAndView addressDetail() {
		
		//Fund fund=(Fund)session.getAttribute("fund");
		ModelAndView mav=new ModelAndView("fundForm3");
		Address address=new Address();
		mav.addObject("address", address);
		log.info("getting in addressDetail");
		return mav;
	}
	
	@PostMapping("/addressDetail")
	public String addAddressDetail(@Valid @ModelAttribute Address address, BindingResult bindingResult) {
		Address ads= addressServiceImpl.addAddress(address);
		//session.setAttribute("address", ads);
		log.info("getting inside addAddressDetail");
		return "userHomePage";
	}
	
	
}
