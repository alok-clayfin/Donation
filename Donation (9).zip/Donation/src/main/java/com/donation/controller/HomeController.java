package com.donation.controller;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.servlet.ModelAndView;

import com.donation.dao.AdminRepository;
import com.donation.model.Fund;
import com.donation.model.User;
import com.donation.service.AdminService;


import lombok.extern.log4j.Log4j2;

@Controller
@Log4j2
public class HomeController {

	private AdminService adminService;
	@Autowired
	private AdminRepository adminRepository;

	@Autowired
	public HomeController(AdminService adminService) {
		// TODO Auto-generated constructor stub
		this.adminService = adminService;
	}

	@GetMapping("/Homepage")
	public String HomePage() {

		return "index";
	}

	@GetMapping("/DonationList")
	public String DonationList() {
		return "donationList";
	}

	@GetMapping("/loggedIn")
	public ModelAndView loggedIn() {
		User user = new User();
		ModelAndView mav = new ModelAndView("loginCustom");
		return mav;
	}

	/*******************************************************************************************************
	 * - Function Name : login() - Input Parameters : @RequestParam
	 * Email, @RequestParam Password - Return Type : Redirect Page - Throws :
	 * ResourceNotFoundException - Author : ALOKSHREE - Description : calls service
	 * method AdminService;
	 ********************************************************************************************************/

	@PostMapping("/dologin")
	public String login(@RequestParam("email") String email, @RequestParam("password") String password,
			HttpSession session) {
		log.info("send from login page" + email);
		log.info("send from login page" + password);
		Boolean value = adminService.existsUserByEmailAndPassword(email, password);
		String role = null;
		if (value == true) {
			role = adminService.findRole(email).getRole();
		}

		if ((value == true) && (role.equals("admin"))) {
			String userRole= adminRepository.findByEmail(email).getRole();
			session.setAttribute("userRole", userRole);
			User user= adminRepository.findByEmail(email);
			session.setAttribute("user", user);
			log.info("going inside admin page");
			return "adminHomePage";
		} else if ((value == true) && (role.equals("user"))) {
			int id= adminRepository.findByEmail(email).getId();
			session.setAttribute("userId", id);
			User user= adminRepository.findByEmail(email);
			session.setAttribute("user", user);
			//addUserInsession(user, session);
			log.info("going inside user page");
			return "userHomePage";
		} else {
			log.info("Invalide input");
			return "redirect:/loggedIn";
		}
	}

//	public void addUserInsession(User user, HttpSession session) {
//		session.setAttribute("user", user);
//		session.setAttribute("userId", user.getId());
//		session.setAttribute("role", user.getRole());
//	}
	
//	@GetMapping("/userFormFund")
//	public ModelAndView profile() {
//		Fund fund=new Fund();
//		ModelAndView mav=new ModelAndView("fundRaiser");
//		mav.addObject("fund", fund);
//		log.info("getting in userDetail");
//		return mav;
//	}
//
//	@PostMapping("/fundForm")
//	public String addUserDetail(@Valid @ModelAttribute Fund fund, BindingResult result, HttpSession session) {
//		System.out.println(fund);
//		//FundUser us=fundUserServiceImpl.addUser(fundUser);
//		
//		//session.setAttribute("fundUser", fundUserServiceImpl.addUser(fundUser));
//		//System.out.println(RequestContextHolder.currentRequestAttributes().getSessionId());
//		log.info("getting in adduserDetail");
//		
//		return "redirect:/userHomePage";	
//	}

}
