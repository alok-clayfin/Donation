package com.donation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.donation.model.Category;
import com.donation.model.Donation;
import com.donation.model.Institution;
import com.donation.service.CategoryService;
import com.donation.service.DonationService;
import com.donation.service.InstitutionService;

@Controller
public class AdminDonationController {

//	@Autowired
//	private CategoryService categoryService;
//
//	@Autowired
//	private InstitutionService institutionService;
	private DonationService donationService;

	@Autowired
	public AdminDonationController(DonationService donationService) {
		// TODO Auto-generated constructor stub
		this.donationService = donationService;
	}
	
	/*******************************************************************************************************
	- Function Name		: getAllDonation()
	- Input Parameters	: object
	- Return Type		: ModelAndView object
	- Throws    		: ResourceNotFoundException
	- Author     		: ALOKSHREE 
	- Description		: calls service method DonationService;
	********************************************************************************************************/
	
	@GetMapping("/donationList")
	public ModelAndView getAllDonation() {
//		List<Category> category= categoryService.viewCategoryList();
//		List<Institution> institution=institutionService.viewInstitutionList();
		ModelAndView mav=new ModelAndView("donationList");
		mav.addObject("donation", donationService.viewDonationList());
//		mav.addObject("category", category);
//		mav.addObject("institution", institution);
		return mav;
	}
}
