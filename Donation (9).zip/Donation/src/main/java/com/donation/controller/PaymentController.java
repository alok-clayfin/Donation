package com.donation.controller;

import java.security.Principal;
import java.util.Map;

import com.donation.dao.AdminRepository;
import com.donation.dao.PaymentRepository;
import com.razorpay.*;
import com.donation.model.Payment;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class PaymentController {
	
	@Autowired
	private PaymentRepository paymentRepository;
	
	@Autowired
	private AdminRepository adminRepository;
	
	/*******************************************************************************************************
	- Function Name		: createOrder()
	- Input Parameters	: @RequestBody Map<String, Object>
	- Return Type		: Redirect Page
	- Throws    		: ResourceNotFoundException
	- Author     		: ALOKSHREE 
	- Description		: calls service method PaymentService;
	********************************************************************************************************/
	
	@PostMapping("/create_order")
	@ResponseBody
	public String createOrder(@RequestBody Map<String, Object> data, Principal principal) throws Exception
	{
		//System.out.println("Hey order function ex.");
		System.out.println(data);
		
		int amt=Integer.parseInt(data.get("amount").toString());
		
		RazorpayClient client=new RazorpayClient("rzp_test_gZvXCirkYtCJ7h", "Qj9WMPb6rnyuThalrN82R3LP");
		
		JSONObject ob=new JSONObject();
		ob.put("amount", amt*100);
		ob.put("currency", "INR");
		ob.put("receipt", "txn_235425");
		
		//creating new order
		
		Order order = client.Orders.create(ob);
		System.out.println(order);
		
		//saving data into database
		
		Payment payment= new Payment();
		payment.setAmount(order.get("amount")+"");
		payment.setOrderId(order.get("id"));
		payment.setPaymentId(null);
		payment.setStatus("created");
		//payment.setUser(this.adminRepository.getUserByUserName(principal.getName()));
		payment.setReceipt(order.get("receipt"));
		this.paymentRepository.save(payment);
		
		
		
		//client.Orders.fetchAll()
		//if you want you can save this to your data..		
		return order.toString();
	}
}
