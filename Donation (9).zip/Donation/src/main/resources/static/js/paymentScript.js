const paymentStart = () => {
	console.log("Payment Started...");
	var amount = $("#payment_field").val();
	console.log(amount);
	if(amount == "" || amount == null){
		alert("amount is required");
		return;
	}
}